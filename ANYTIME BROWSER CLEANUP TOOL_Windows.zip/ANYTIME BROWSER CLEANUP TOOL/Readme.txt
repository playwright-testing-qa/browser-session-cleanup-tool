ANYTIME TELECARE TECH TOOL
Browser Cleanup Utility

Purpose:
This tool clears browser session data, cookies, cache, and local site storage for Chrome and Edge.

It is intended to help resolve login/session-related issues such as:
- expired sessions
- stale login state
- token/session issues
- browser cache problems

Before running:
1. Make sure you are NOT on an active call or encounter.
2. Save any work if needed.
3. Fully close all Chrome and Edge windows.
4. Run Anytime_Clear_Browser_Data.bat.
5. Reopen the browser and log in again.

This tool clears:
- Cache
- Code Cache
- GPU Cache
- Cookies
- Session Storage
- Local Storage
- IndexedDB
- Service Worker cache

This tool is intended NOT to delete:
- Saved passwords
- Bookmarks
- Browser profiles
- Extensions

Important:
Do not run this tool during an active call or encounter.

Provided by Anytime Telecare Tech.
Unauthorized modification is not recommended.